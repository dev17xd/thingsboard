package org.thingsboard.pe.app.flutter_thingsboard_pe_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
